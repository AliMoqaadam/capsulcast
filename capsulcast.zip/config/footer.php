<footer class="footer-area">
    <div class="footer-widget">
        <div class="container">
            <div class="footer-widget-wrapper pt-80 pb-30">
                <div class="row">
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-widget-box about-us">
                            <a href="#" class="footer-logo">
                                <img src="images/logo.png" class="logo-dark-mode" alt="">
                                <img src="images/logo-dark.png" class="logo-light-mode" alt="">
                            </a>
                            <p class="mb-3">
                                ما در <a href="#" style="color: #00A6FF;"><strong>کپسول کست</strong></a> در تلاشیم که بهترین پادکست‌ها را برای شما عزیزان تهیه کرده و به اشتراک بگذاریم تا نهایت استفاده را ببرید
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-widget-box list">
                            <h4 class="footer-widget-title">درباره ما</h4>
                            <ul class="footer-list">
                                <li><a href="about.html">درباره ما</a></li>
                                <li><a href="testimonial.html">تماس با ما</a></li>
                                <li><a href="blog.html">کانال ما</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-widget-box list">
                            <h4 class="footer-widget-title">لینک‌های مفید</h4>
                            <ul class="footer-list">
                                <li><a href="show.html">وبلاگ</a></li>
                                <li><a href="episode-grid.html">سوالات متداول</a></li>
                                <li><a href="host.html">شرایط و قوانین</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-widget-box list">
                            <h4 class="footer-widget-title">کانال ما</h4>
                            <div class="footer-newsletter">
                                <p>برای دریافت آخرین اخبار کپسول کست کانال تلگرامی ما را دنبال کنید</p>
                                <div class="subscribe-form">
                                    <a href="#" class="theme-btn">
                                        عضو شوید<i class="far fa-paper-plane"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="copyright">
            <div class="row">
                <div class="col-12 align-self-center text-center">
                    <p class="copyright-text">
                        تمامی حقوق برای <a href="#">کپسول کست</a> محفوظ می‌باشد
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>