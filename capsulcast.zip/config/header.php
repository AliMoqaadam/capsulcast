<header class="header">
    <div class="main-navigation">
        <nav class="navbar navbar-expand-lg">
            <div class="container position-relative">
                <a class="navbar-brand" href="https://capsulcast.ir">
                    <img src="images/logo.png" class="logo-display" alt="logo">
                    <img src="images/logo-dark.png" class="logo-scrolled" alt="logo">
                </a>

                <div class="mobile-menu-right">
                    <div class="nav-search-wrap">
                        <div class="search-btn">
                            <button type="button" class="nav-right-link search-box-outer"><i
                                    class="feather-search"></i></button>
                        </div>
                    </div>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-mobile-icon"><i class="feather-menu"></i></span>
                    </button>
                </div>

                <div class="collapse navbar-collapse" id="main_nav">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="https://capsulcast.ir">خانه</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">دسته بندی‌ها</a>
                            <ul class="dropdown-menu fade-down">
                                <li><a class="dropdown-item" href="#">بازاریابی</a></li>
                                <li><a class="dropdown-item" href="#">توسعه فردی</a></li>
                                <li><a class="dropdown-item" href="#">هوش مصنوعی</a></li>
                                <li><a class="dropdown-item" href="#">بازارهای مالی</a></li>
                                <li><a class="dropdown-item" href="#">کسب و کار</a></li>
                                <li><a class="dropdown-item" href="#">تکنولوژی</a></li>
                                <li><a class="dropdown-item" href="#">مدیریت</a></li>
                                <li><a class="dropdown-item" href="#">زبان انگلیسی</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="blog.php">وبلاگ</a>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="about.php">درباره ما</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact.php">تماس با ما</a></li>
                    </ul>
                    <div class="nav-right">
                        <div class="search-btn">
                            <button type="button" class="nav-right-link search-box-outer"><i
                                    class="feather-search"></i></button>
                        </div>
                        <div class="nav-right-btn">
                            <?php
                                if(!isset($_SESSION['login'])) {
                                    echo '<a href="./login.php" class="theme-btn">ورود | ثبت نام</a>';
                                } else {
                                    echo '<a href="./login.php" class="theme-btn">حساب کاربری</a>';
                                }
                            ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</header>

<div class="search-popup">
    <button class="close-search"><span class="far fa-times"></span></button>
    <form action="#">
        <div class="form-group">
            <input type="search" name="search-field" placeholder="اینجا جستجو کنید" required="">
            <button type="submit"><i class="far fa-search"></i></button>
        </div>
    </form>
</div>