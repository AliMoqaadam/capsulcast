<?php
    session_start();
    
    $dbHost = "localhost";
    $dbUser = "root";
    $dbPass = "";
    $dbName = "capsulcast";
    
    $conn = mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);
    
    if (!$conn) {
        die("اتصال به پایگاه داده برقرار نشد: " . mysqli_connect_error());
    }
?>